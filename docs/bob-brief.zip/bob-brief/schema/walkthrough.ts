/**
 * Walkthrough schema — the contract between the analyzer (Bob Shell / fallback LLM)
 * and everything else (backend validation, coverage, TTS, React viewer).
 *
 * Design rules encoded here:
 *  - The analyzer decides ORDER and MEANING. The backend decides FACTS it can check
 *    (hunks, coverage, whether quoted code lines really exist).
 *  - Every step and every line annotation carries a SourceTag, so inference is never
 *    presented as fact.
 *  - Two language levels: `narration` (spoken, no identifiers) vs `annotation`
 *    (precise, next to a code line).
 */

/** Where a claim comes from. The UI shows this as a chip on every step. */
export type SourceTag =
  | "fact" // directly visible in the diff, the code, a code comment, or a test
  | "commit_history" // stated in commit messages / squashed commit bullet list
  | "inferred" // the analyzer's own conclusion from reading code; not stated by the author
  | "unverified"; // a claim or scenario nobody has executed yet

/** What role a step plays in the story. Order of steps is by reasoning, not by file. */
export type StepKind =
  | "symptom" // what the user/reviewer sees going wrong
  | "cause" // why it goes wrong
  | "constraint" // what prevents the obvious local fix
  | "data_origin" // where the needed data is born / lives
  | "decision" // the key idea of the solution
  | "change" // a concrete edit that implements the decision
  | "alternative_rejected" // a plausible alternative the PR did not take
  | "dead_end" // an approach the author tried and replaced (from commit history)
  | "open_question" // something the reviewer should ask/check
  | "verification"; // how the fix is (or would be) proven

export interface Walkthrough {
  schemaVersion: 1;
  pr: PullRequestMeta;
  summary: {
    /** One or two sentences, plain language: what was broken. */
    problem: string;
    /** One or two sentences, plain language: the core idea of the fix. */
    solution: string;
  };
  /** Parsed by the BACKEND from the diff, never invented by the analyzer. */
  hunks: Hunk[];
  graph: Graph;
  steps: Step[];
  /** Hunks deliberately not explained in steps (imports, renames, type plumbing...). */
  skippedHunks: SkippedHunk[];
  openQuestions: OpenQuestion[];
  /** Computed by the BACKEND from hunks + steps[].hunkIds + skippedHunks. */
  coverage?: Coverage;
  verification?: Verification;
  meta: {
    analyzer: "bob-shell" | "claude" | "watsonx" | "manual";
    model?: string;
    generatedAt: string; // ISO date
    durationMs?: number;
    /** Output language of narration/text, e.g. "en", "uk". */
    language: string;
  };
}

export interface PullRequestMeta {
  repo: string; // "outline/outline"
  number: number;
  title: string;
  url: string;
  author: string;
  mergedAt?: string;
  baseSha?: string;
  headSha?: string;
  filesChanged: number;
  additions: number;
  deletions: number;
  /** Commit titles in order. For squash merges: the bullet list from the squash message. */
  commitTitles: string[];
  body?: string;
  linkedIssues?: { number: number; title: string; url: string }[];
}

export interface Hunk {
  /** Stable id: `${file}#${1-based hunk index within file}` */
  id: string;
  file: string;
  header: string; // "@@ -80,22 +80,38 @@ function RevisionViewer(...)"
  added: number;
  removed: number;
}

export interface SkippedHunk {
  hunkId: string;
  /** Short reason shown in the "skipped" list, e.g. "removed unused import". */
  reason: string;
}

// ---------------------------------------------------------------------------
// Graph: files/modules and how data flows between them. Changes across steps.
// ---------------------------------------------------------------------------

export interface Graph {
  nodes: GraphNode[];
  edges: GraphEdge[];
}

export interface GraphNode {
  id: string;
  label: string; // "RevisionViewer"
  sublabel?: string; // "renders the diff editor"
  file?: string; // repo-relative path, if the node is a file
  kind: "file" | "module" | "runtime" | "external";
  /** Optional layout hint. The product may auto-layout (dagre/elk) and ignore this. */
  layout?: { col: number; row: number };
  /** 1-based step number from which the node exists (e.g. a new file). Default: always. */
  visibleFrom?: number;
}

export interface GraphEdge {
  id: string;
  from: string;
  to: string;
  label?: string;
  kind: "props" | "call" | "data" | "event" | "import";
  /** "before" = removed by the PR, "after" = introduced by the PR, "unchanged" = context. */
  state: "before" | "after" | "unchanged";
  /** Draw as the problematic path (e.g. red dashed). */
  problem?: boolean;
  /** 1-based step numbers controlling when the edge is drawn. */
  visibleFrom?: number;
  visibleUntil?: number;
}

// ---------------------------------------------------------------------------
// Steps
// ---------------------------------------------------------------------------

export interface Step {
  id: string; // "s1"
  kind: StepKind;
  /** Short label for the route rail, ≤ 4 words. */
  routeLabel: string;
  /** Full step title, one line. */
  title: string;
  /** Graph node this step is "standing on". Consecutive steps on different nodes draw a hop. */
  focusNode: string;
  tag: SourceTag;
  /** Rendered struck-through in the route rail (dead ends, rejected alternatives). */
  isDeadEnd?: boolean;
  /**
   * Spoken by TTS. 2–4 sentences. Plain language, NO identifiers, NO file names,
   * explains intent ("we need to keep the count somewhere the header can read it"),
   * never re-reads the code.
   */
  narration: string;
  /** 1–3 beats, in this order when present: current → problem → change. */
  beats: Beat[];
  /** Diff hunks this step explains. Used for coverage. */
  hunkIds: string[];
  /** Minor edits in these hunks that are intentionally not explained. */
  skipped?: string[];
  /** Extra remarks shown in muted text (e.g. why something is inferred). */
  notes?: string[];
  sources: SourceRef[];
}

export interface Beat {
  kind: "current" | "problem" | "change";
  heading: string; // "How it works now" / "What breaks" / "What we change"
  text: string; // 1–3 sentences, may mention identifiers in `backticks`
  code?: CodeBlock[];
  /** Concrete value traces, e.g. [?changes] → [get() → ""] → [return null]. */
  traces?: TraceStep[][];
}

export interface CodeBlock {
  file: string;
  /** Which version the lines are quoted from. The backend verifies quoted lines exist there. */
  revision: "base" | "head" | "diff";
  label?: string; // "before the change", "unchanged code", "test"
  /**
   * true = lines are NOT in any revision (e.g. an intermediate version reconstructed
   * from a commit title). Must also set tag "inferred" on the step or annotation.
   */
  reconstructed?: boolean;
  lines: CodeLine[];
}

export interface CodeLine {
  kind: "context" | "focus" | "added" | "removed" | "elided";
  /** Verbatim source text (except kind "elided", which is a short placeholder like "…"). */
  text: string;
  /** Only on load-bearing lines. One sentence. Shown under the line as "↳ ...". */
  annotation?: string;
  annotationTag?: SourceTag;
}

export interface TraceStep {
  label: string;
  status?: "ok" | "bad" | "neutral";
}

export interface SourceRef {
  type:
    | "diff"
    | "code"
    | "code_comment"
    | "commit_message"
    | "pr_title"
    | "pr_description"
    | "linked_issue"
    | "code_search"
    | "test"
    | "inference";
  /** Human-readable pointer: file:line, commit title, issue number, search query... */
  ref: string;
}

export interface OpenQuestion {
  id: string;
  stepId: string;
  question: string; // phrased as a reviewer would ask the author
  why: string; // what in the code made the analyzer ask
  tag: SourceTag; // usually "inferred"
}

export interface Coverage {
  totalHunks: number;
  explained: number;
  skipped: number;
  /** Hunks referenced by neither a step nor skippedHunks — shown as a warning. */
  uncoveredHunkIds: string[];
}

export interface Verification {
  status: "not_run" | "passed" | "failed";
  /** Human-readable scenario, one action → expectation per line. */
  scenario: string[];
  baseVideoUrl?: string;
  headVideoUrl?: string;
  testOutput?: string;
}
